#include "calculator.h"

Calculator::Calculator(QList<int> endPoints, QList<Group> groups, Model *model,QString outFileName, QObject *parent) :
    QThread(parent),
    m_endPoints(endPoints),
    m_groups(groups),
    m_model(model)
{

    outfile = new QFile(outFileName, this);
    outfile->remove();
    writeHeader();
}

void Calculator::run()
{
    iteration = 0;
    for(int i=0;i<m_endPoints.count();i++)
    {
        m_model->calculateSurfaces(0,m_endPoints[i]-m_model->getStartRes());
        countGroups(m_endPoints[i]);
    }

}

void Calculator::countGroups(int endPoint)
{
    QList<int> count;
    for(int j=0;j<m_groups.count();j++)
    {
        int c = 0;
        for(int k=0;k<m_groups[j].AminoAcids.count();k++)
        {
            bool check = false;
            for(int i=0;i<m_model->getResidues().count();i++)
            {
                if(m_model->getResidues()[i]->serial() == endPoint)
                {
                    check = true;
                    break;
                }
                if(m_model->getResidues()[i]->name() == m_groups[j].AminoAcids[k])
                {
                    c+=m_model->getResidues()[i]->accessibility();
                }
            }
            if(!check)
            {
                cout << "didnt see "<< endPoint << "end point\n";
                return;
            }

        }
        count.append(c);
    }
    writeToFile(endPoint,count);

}

void Calculator::writeToFile(int endPoint, QList<int> counts)
{
    QString toWrite="";
    toWrite += QString::number(iteration++) + "\t";
    toWrite += QString::number(endPoint) + "\t";

    for(int i=0;i<counts.count();i++)
    {
        toWrite.append(QString::number(counts[i]) + "\t");
    }
    toWrite.append("\r\n");
    outfile->open(QFile::Append);
    outfile->write(toWrite.toLatin1());
    outfile->close();
}

void Calculator::writeHeader()
{
    outfile->open(QFile::Append);
    QString toWrite="";
    toWrite = "=== Accsessible Area Calculation by Roozbeh Hajizadeh ======\r\n";
    int n=toWrite.count();
    for(int i=0;i<m_groups.count();i++)
    {
        toWrite += m_groups[i].name + ": ";
        for(int j=0;j<m_groups[i].AminoAcids.count();j++)
        {
            toWrite += m_groups[i].AminoAcids[j] + " ";
        }
        toWrite += "\r\n";
    }
    for(int i=0;i<n;i++)
        toWrite += "-";
    toWrite += "\r\n";
    outfile->write(toWrite.toLatin1());
    toWrite="#\tend\t";

    for(int i=0;i<m_groups.count();i++)
    {
        toWrite += m_groups[i].name + "\t";
    }
    toWrite += "\r\n";

    outfile->write(toWrite.toLatin1());
    outfile->close();
}
