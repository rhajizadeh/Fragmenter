#include "chain.h"

Chain::Chain(QObject *parent) :
    QObject(parent)
{
}

QList<Residue *> Chain::residues()
{
    return m_residues;
}

void Chain::addResidue(Residue *residue)
{
    m_residues.append(residue);
}
