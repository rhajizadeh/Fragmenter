#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QFile>
#include <QRunnable>
#include <QThread>
#include "model.h"
#include <iostream>

using namespace std;

struct Group
{
    QString name;
    QStringList AminoAcids;
};

class Calculator : public QThread
{
    Q_OBJECT
public:
    explicit Calculator(QList<int> endPoints, QList<Group> groups, Model* model, QString outFileName, QObject *parent = 0);

protected:
    void run();

private:
    QList<int> m_endPoints;
    QList<Group> m_groups;
    Model *m_model;

    QFile *outfile;
    void countGroups(int endPoint);
    void writeToFile(int endPoint, QList<int> counts);
    void writeHeader();
    int iteration;
signals:
    
public slots:
    
};


#endif // CALCULATOR_H
