#include "model.h"

#include <QThread>
Model::~Model()
{
    xmin =0;
    xmax =0;
    ymin =0;
    ymax =0;
    zmax = 0;
    zmin = 0;
    Atom *atom;
    while(atoms.count()>0)
    {
        atom = atoms.takeFirst();
        delete atom;
    }
}

Model::Model(Model &model)
{
    startRes = model.startRes;
    Atom *atom;
    for(int i=0;i<model.atomsCount();i++)
    {
        atom = new Atom(*model.atomAt(i));
    }
    m_isProtein = true;

}
void Model::addAtom(Atom *atom)
{
//    int i = m_chains.indexOf(atom->chain());
//    if(i==-1)
//    {
//        m_chains.append(atom->chain());
//    }

    updateRange(atom->x(),atom->y(),atom->z());
    atoms.append(atom);

}

void Model::addResidue(Residue *residue)
{

    m_residues.append(residue);
    if(!residue->isAminoAcid())
        m_isProtein = false;

    if(startRes == 0 ||  startRes > residue->serial())
    {
       startRes = residue->serial();
    }
}


void Model::calculateHBondEnergies(QList<Residue *> inResidues)
{
    for (quint32 i = 0; i + 1 < inResidues.size(); ++i)
    {
        Residue* ri = inResidues[i];

        for (quint32 j = i + 1; j < inResidues.size(); ++j)
        {
            Residue* rj = inResidues[j];

            if (ri->getCA()->center().distanceToPoint(rj->getCA()->center()) < kMinimalCADistance)
            {
                Residue::calculateHBondEnergy(ri, rj);
                if (j != i + 1)
                    Residue::calculateHBondEnergy(rj, ri);
            }
        }
    }
}

void Model::calculateSurfaces()
{
    QList<Residue*> residues = getResidues();
    QList<Residue*>::Iterator it1;
    for(it1=residues.begin(); it1<residues.end(); it1++)
    {
        (*it1)->calculateSurface(residues);

    }
    calculateHBondEnergies(residues);
}

void Model::calculateSurfaces(int from, int to)
{
    QList<Residue*> residues = getResidues();
    QList<Residue*> residues2;
    QList<Residue*>::Iterator it1;
    int i=1;
    for(it1=residues.begin(); it1<residues.end(); it1++)
    {
        (*it1)->resetAccessibility();
        if(i>to)
            break;
        if(i>=from)
            residues2.append(*it1);

        i++;
    }

    for(it1=residues2.begin(); it1<residues2.end(); it1++)
    {
        (*it1)->calculateSurface(residues2);
    }
    calculateHBondEnergies(residues2);
}

QList<Residue *> Model::getResidues()
{
    return m_residues;
}

void Model::updateRange(qreal x, qreal y, qreal z)
{
    //    qDebug() << xmin << xmax;
    xmin = xmin > x ? x : xmin;
    //    qDebug() << xmin << x << y << z;
    xmax = xmax < x ? x : xmax;

    ymin = ymin > y ? y : ymin;
    ymax = ymax < y ? y : ymax;

    zmin = zmin > z ? z : zmin;
    zmax = zmax < z ? z : zmax;

}

bool Model::isProtein() const
{
    return m_isProtein;
}

void Model::setIsProtein(bool isProtein)
{
    m_isProtein = isProtein;
}
