#include "pdbparser.h"

#include <iostream>
#include "pdbparser.h"
#include "calculator.h"

using namespace std;


QString outPut;
QString pdbFileName;
QString confFile;
QList<int> endPoints;
QList<Group> groups;

bool parseArguments(int argc,char *argv[],QString &message)
{

    QString current;
    for(int i=0;i<argc;i++)
    {
        current = QString::fromLatin1(argv[i]);
        if(current=="-o")
        {
            if(i<argc-1)
            {
                outPut = QString::fromLatin1(argv[i+1]);
                i++;
            }
            else
            {
                message = "no output file";
                return false;
            }
        }
        else if(current=="-i")
        {
            if(i<argc-1)
            {
                pdbFileName = QString::fromLatin1(argv[i+1]);
                i++;
            }
            else
            {
                message = "no input file";
                return false;
            }
        }
        else if(current=="-c")
        {
            if(i<argc-1)
            {
                confFile = QString::fromLatin1(argv[i+1]);
                i++;
            }
            else
            {
                message = "no config file";
                return false;
            }
        }
    }
    return true;
}

bool parseConfigfile(QString &message)
{
    QFile file(confFile);
    if(!file.open(QFile::ReadOnly))
    {
        message = "error opening file";
        return false;
    }
    QString temp(file.readAll());
    file.close();

    temp = temp.trimmed();

    QStringList lines = temp.split('\n');
    for(int i=0;i<lines.count();i++)
    {
        QString s = lines[i].split(':')[0].trimmed();
        QString arg = lines[i].split(':')[1].trimmed();
        if(s=="")
            continue;
        if(arg=="")
        {
            message = "error in config file: argument of: " + s;
            return false;
        }
        if(s=="fgs")
        {
            QStringList pointsString = arg.split(',');
            int num=0;
            bool check = false;
            for(int i=0;i<pointsString.count();i++)
            {
                check = false;
                num = pointsString[i].toInt(&check);
                if(!check)
                {
                    message = "error in config file: wrong end point";
                    return false;
                }
                endPoints.append(num);
            }
        }
        else
        {
            Group p = {s, arg.split(' ')};
            groups.append(p);
        }
    }
    return true;
}

int main(int argc, char *argv[])
{
    QString message;
    if(!parseArguments(argc, argv, message))
    {
        cout << message.toStdString();
        return -1;
    }
    if(!parseConfigfile(message))
    {
        cout << message.toStdString();
        return -1;
    }
    PdbParser *parser = new PdbParser();
    parser->setFileName(pdbFileName);
    cout << "Parsing PDB file...\n";
    parser->start();
    parser->wait();
    cout  << "Parsing done!\n";
    cout  << "Calculating...\n";
    Calculator *cal = new Calculator(endPoints,groups,parser->models()[0],outPut);
    cal->start();
    cal->wait();

    return 0;
}
